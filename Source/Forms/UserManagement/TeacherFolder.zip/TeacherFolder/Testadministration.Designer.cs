﻿namespace Student_Assessment_System_with_Item_Analysis.Source.Forms
{
    partial class Testadministration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Testadministration));
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTestSetup = new System.Windows.Forms.Label();
            this.lblTestTaking = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbAllow = new System.Windows.Forms.CheckBox();
            this.cbShow = new System.Windows.Forms.CheckBox();
            this.cbRandomizeA = new System.Windows.Forms.CheckBox();
            this.cbRandomizeQ = new System.Windows.Forms.CheckBox();
            this.lblTestSettings = new System.Windows.Forms.Label();
            this.btnAssign = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.cbPeriod3 = new System.Windows.Forms.CheckBox();
            this.cbPeriod2 = new System.Windows.Forms.CheckBox();
            this.cbPeriod1 = new System.Windows.Forms.CheckBox();
            this.lblSelect = new System.Windows.Forms.Label();
            this.lblConfig = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtbAuto = new System.Windows.Forms.TextBox();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.rdn4 = new System.Windows.Forms.RadioButton();
            this.btn9 = new System.Windows.Forms.Button();
            this.rdn3 = new System.Windows.Forms.RadioButton();
            this.btn8 = new System.Windows.Forms.Button();
            this.rdn2 = new System.Windows.Forms.RadioButton();
            this.btn7 = new System.Windows.Forms.Button();
            this.rdn1 = new System.Windows.Forms.RadioButton();
            this.btn6 = new System.Windows.Forms.Button();
            this.lblT = new System.Windows.Forms.Label();
            this.btn5 = new System.Windows.Forms.Button();
            this.lblQuestions = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.lblProgramming = new System.Windows.Forms.Label();
            this.btn2 = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblLogout = new System.Windows.Forms.Label();
            this.pbNotif = new System.Windows.Forms.PictureBox();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNotif)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.button3);
            this.panel6.Controls.Add(this.button5);
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.button7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(160, 712);
            this.panel6.TabIndex = 62;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(44, 25);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(68, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 48;
            this.pictureBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-3, 395);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(163, 48);
            this.button1.TabIndex = 46;
            this.button1.Text = "📊 Reports";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-3, 323);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(163, 46);
            this.button2.TabIndex = 45;
            this.button2.Text = "💻 Test Administration";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(-3, 466);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(163, 48);
            this.button3.TabIndex = 47;
            this.button3.Text = "⚙️ Settings";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(-3, 250);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(160, 49);
            this.button5.TabIndex = 43;
            this.button5.Text = "❔ Question Bank";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 184);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(160, 60);
            this.button6.TabIndex = 42;
            this.button6.Text = "📚 Subjects and Courses";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 125);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(160, 53);
            this.button7.TabIndex = 41;
            this.button7.Text = "🏠︎ Dashboard";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.SteelBlue;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(178, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(270, 37);
            this.label9.TabIndex = 80;
            this.label9.Text = "Test Administration";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // lblTestSetup
            // 
            this.lblTestSetup.AutoSize = true;
            this.lblTestSetup.BackColor = System.Drawing.Color.White;
            this.lblTestSetup.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTestSetup.Location = new System.Drawing.Point(12, 17);
            this.lblTestSetup.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTestSetup.Name = "lblTestSetup";
            this.lblTestSetup.Size = new System.Drawing.Size(88, 21);
            this.lblTestSetup.TabIndex = 94;
            this.lblTestSetup.Text = "Test Setup";
            // 
            // lblTestTaking
            // 
            this.lblTestTaking.AutoSize = true;
            this.lblTestTaking.BackColor = System.Drawing.Color.White;
            this.lblTestTaking.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTestTaking.Location = new System.Drawing.Point(22, 15);
            this.lblTestTaking.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTestTaking.Name = "lblTestTaking";
            this.lblTestTaking.Size = new System.Drawing.Size(95, 21);
            this.lblTestTaking.TabIndex = 119;
            this.lblTestTaking.Text = "Test Taking";
            // 
            // textBox12
            // 
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Location = new System.Drawing.Point(2, 2);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(469, 402);
            this.textBox12.TabIndex = 120;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.SteelBlue;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.ForeColor = System.Drawing.Color.White;
            this.textBox15.Location = new System.Drawing.Point(158, 0);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(1077, 97);
            this.textBox15.TabIndex = 150;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnSearch.Location = new System.Drawing.Point(821, 40);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(234, 29);
            this.btnSearch.TabIndex = 151;
            this.btnSearch.Text = "⌕ Search tests...\r\n";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbAllow);
            this.panel1.Controls.Add(this.cbShow);
            this.panel1.Controls.Add(this.cbRandomizeA);
            this.panel1.Controls.Add(this.cbRandomizeQ);
            this.panel1.Controls.Add(this.lblTestSettings);
            this.panel1.Controls.Add(this.btnAssign);
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.cbPeriod3);
            this.panel1.Controls.Add(this.cbPeriod2);
            this.panel1.Controls.Add(this.cbPeriod1);
            this.panel1.Controls.Add(this.lblSelect);
            this.panel1.Controls.Add(this.lblConfig);
            this.panel1.Controls.Add(this.lblTestSetup);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(183, 108);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 406);
            this.panel1.TabIndex = 155;
            // 
            // cbAllow
            // 
            this.cbAllow.AutoSize = true;
            this.cbAllow.BackColor = System.Drawing.Color.White;
            this.cbAllow.Location = new System.Drawing.Point(69, 373);
            this.cbAllow.Name = "cbAllow";
            this.cbAllow.Size = new System.Drawing.Size(248, 17);
            this.cbAllow.TabIndex = 163;
            this.cbAllow.Text = "Allow Students to review questions and answer";
            this.cbAllow.UseVisualStyleBackColor = false;
            // 
            // cbShow
            // 
            this.cbShow.AutoSize = true;
            this.cbShow.BackColor = System.Drawing.Color.White;
            this.cbShow.Location = new System.Drawing.Point(69, 340);
            this.cbShow.Name = "cbShow";
            this.cbShow.Size = new System.Drawing.Size(237, 17);
            this.cbShow.TabIndex = 162;
            this.cbShow.Text = "Show/hide correct answers after submission ";
            this.cbShow.UseVisualStyleBackColor = false;
            // 
            // cbRandomizeA
            // 
            this.cbRandomizeA.AutoSize = true;
            this.cbRandomizeA.BackColor = System.Drawing.Color.White;
            this.cbRandomizeA.Location = new System.Drawing.Point(69, 305);
            this.cbRandomizeA.Name = "cbRandomizeA";
            this.cbRandomizeA.Size = new System.Drawing.Size(156, 17);
            this.cbRandomizeA.TabIndex = 161;
            this.cbRandomizeA.Text = "Randomize answer choices";
            this.cbRandomizeA.UseVisualStyleBackColor = false;
            // 
            // cbRandomizeQ
            // 
            this.cbRandomizeQ.AutoSize = true;
            this.cbRandomizeQ.BackColor = System.Drawing.Color.White;
            this.cbRandomizeQ.Location = new System.Drawing.Point(69, 274);
            this.cbRandomizeQ.Name = "cbRandomizeQ";
            this.cbRandomizeQ.Size = new System.Drawing.Size(122, 17);
            this.cbRandomizeQ.TabIndex = 159;
            this.cbRandomizeQ.Text = "Randomize question";
            this.cbRandomizeQ.UseVisualStyleBackColor = false;
            // 
            // lblTestSettings
            // 
            this.lblTestSettings.AutoSize = true;
            this.lblTestSettings.BackColor = System.Drawing.Color.White;
            this.lblTestSettings.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTestSettings.Location = new System.Drawing.Point(13, 240);
            this.lblTestSettings.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTestSettings.Name = "lblTestSettings";
            this.lblTestSettings.Size = new System.Drawing.Size(106, 21);
            this.lblTestSettings.TabIndex = 156;
            this.lblTestSettings.Text = "Test Settings";
            // 
            // btnAssign
            // 
            this.btnAssign.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAssign.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAssign.ForeColor = System.Drawing.Color.White;
            this.btnAssign.Location = new System.Drawing.Point(385, 196);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(75, 23);
            this.btnAssign.TabIndex = 157;
            this.btnAssign.Text = "Assign Test";
            this.btnAssign.UseVisualStyleBackColor = false;
            // 
            // btnBack
            // 
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Location = new System.Drawing.Point(304, 196);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 156;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // cbPeriod3
            // 
            this.cbPeriod3.AutoSize = true;
            this.cbPeriod3.BackColor = System.Drawing.Color.White;
            this.cbPeriod3.Location = new System.Drawing.Point(69, 174);
            this.cbPeriod3.Name = "cbPeriod3";
            this.cbPeriod3.Size = new System.Drawing.Size(65, 17);
            this.cbPeriod3.TabIndex = 160;
            this.cbPeriod3.Text = "Period 3";
            this.cbPeriod3.UseVisualStyleBackColor = false;
            // 
            // cbPeriod2
            // 
            this.cbPeriod2.AutoSize = true;
            this.cbPeriod2.BackColor = System.Drawing.Color.White;
            this.cbPeriod2.Location = new System.Drawing.Point(69, 151);
            this.cbPeriod2.Name = "cbPeriod2";
            this.cbPeriod2.Size = new System.Drawing.Size(65, 17);
            this.cbPeriod2.TabIndex = 159;
            this.cbPeriod2.Text = "Period 2";
            this.cbPeriod2.UseVisualStyleBackColor = false;
            // 
            // cbPeriod1
            // 
            this.cbPeriod1.AutoSize = true;
            this.cbPeriod1.BackColor = System.Drawing.Color.White;
            this.cbPeriod1.Location = new System.Drawing.Point(69, 128);
            this.cbPeriod1.Name = "cbPeriod1";
            this.cbPeriod1.Size = new System.Drawing.Size(65, 17);
            this.cbPeriod1.TabIndex = 158;
            this.cbPeriod1.Text = "Period 1";
            this.cbPeriod1.UseVisualStyleBackColor = false;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.BackColor = System.Drawing.Color.White;
            this.lblSelect.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelect.Location = new System.Drawing.Point(14, 101);
            this.lblSelect.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(86, 13);
            this.lblSelect.TabIndex = 157;
            this.lblSelect.Text = "Select Sections:";
            // 
            // lblConfig
            // 
            this.lblConfig.AutoSize = true;
            this.lblConfig.BackColor = System.Drawing.Color.White;
            this.lblConfig.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfig.Location = new System.Drawing.Point(13, 66);
            this.lblConfig.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblConfig.Name = "lblConfig";
            this.lblConfig.Size = new System.Drawing.Size(201, 17);
            this.lblConfig.TabIndex = 156;
            this.lblConfig.Text = "Configure Programming Quiz 1";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(2, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(472, 401);
            this.textBox1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnSubmit);
            this.panel2.Controls.Add(this.txtbAuto);
            this.panel2.Controls.Add(this.btn11);
            this.panel2.Controls.Add(this.btn10);
            this.panel2.Controls.Add(this.rdn4);
            this.panel2.Controls.Add(this.btn9);
            this.panel2.Controls.Add(this.rdn3);
            this.panel2.Controls.Add(this.btn8);
            this.panel2.Controls.Add(this.rdn2);
            this.panel2.Controls.Add(this.btn7);
            this.panel2.Controls.Add(this.rdn1);
            this.panel2.Controls.Add(this.btn6);
            this.panel2.Controls.Add(this.lblT);
            this.panel2.Controls.Add(this.btn5);
            this.panel2.Controls.Add(this.lblQuestions);
            this.panel2.Controls.Add(this.btn1);
            this.panel2.Controls.Add(this.lblProgramming);
            this.panel2.Controls.Add(this.btn2);
            this.panel2.Controls.Add(this.lblWelcome);
            this.panel2.Controls.Add(this.btn4);
            this.panel2.Controls.Add(this.lblTestTaking);
            this.panel2.Controls.Add(this.btn3);
            this.panel2.Controls.Add(this.textBox12);
            this.panel2.Location = new System.Drawing.Point(722, 110);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(473, 406);
            this.panel2.TabIndex = 156;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(362, 356);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 158;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            // 
            // txtbAuto
            // 
            this.txtbAuto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtbAuto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbAuto.Location = new System.Drawing.Point(26, 348);
            this.txtbAuto.Multiline = true;
            this.txtbAuto.Name = "txtbAuto";
            this.txtbAuto.Size = new System.Drawing.Size(426, 40);
            this.txtbAuto.TabIndex = 157;
            this.txtbAuto.Text = "    ⚠️ Time will auto submit\r\n    10/20 points answered so far.";
            // 
            // btn11
            // 
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn11.Location = new System.Drawing.Point(337, 310);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(48, 23);
            this.btn11.TabIndex = 176;
            this.btn11.Text = ">>";
            this.btn11.UseVisualStyleBackColor = true;
            // 
            // btn10
            // 
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10.Location = new System.Drawing.Point(306, 310);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(37, 23);
            this.btn10.TabIndex = 175;
            this.btn10.Text = "10";
            this.btn10.UseVisualStyleBackColor = true;
            // 
            // rdn4
            // 
            this.rdn4.AutoSize = true;
            this.rdn4.BackColor = System.Drawing.Color.White;
            this.rdn4.Location = new System.Drawing.Point(61, 272);
            this.rdn4.Name = "rdn4";
            this.rdn4.Size = new System.Drawing.Size(81, 17);
            this.rdn4.TabIndex = 164;
            this.rdn4.TabStop = true;
            this.rdn4.Text = "Foreign Key";
            this.rdn4.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Location = new System.Drawing.Point(282, 310);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(27, 23);
            this.btn9.TabIndex = 174;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            // 
            // rdn3
            // 
            this.rdn3.AutoSize = true;
            this.rdn3.BackColor = System.Drawing.Color.White;
            this.rdn3.Location = new System.Drawing.Point(61, 249);
            this.rdn3.Name = "rdn3";
            this.rdn3.Size = new System.Drawing.Size(80, 17);
            this.rdn3.TabIndex = 163;
            this.rdn3.TabStop = true;
            this.rdn3.Text = "Primary Key";
            this.rdn3.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Location = new System.Drawing.Point(257, 310);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(29, 23);
            this.btn8.TabIndex = 173;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            // 
            // rdn2
            // 
            this.rdn2.AutoSize = true;
            this.rdn2.BackColor = System.Drawing.Color.White;
            this.rdn2.Location = new System.Drawing.Point(61, 227);
            this.rdn2.Name = "rdn2";
            this.rdn2.Size = new System.Drawing.Size(59, 17);
            this.rdn2.TabIndex = 162;
            this.rdn2.TabStop = true;
            this.rdn2.Text = "Unique";
            this.rdn2.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Location = new System.Drawing.Point(233, 310);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(27, 23);
            this.btn7.TabIndex = 172;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            // 
            // rdn1
            // 
            this.rdn1.AutoSize = true;
            this.rdn1.BackColor = System.Drawing.Color.White;
            this.rdn1.Location = new System.Drawing.Point(62, 204);
            this.rdn1.Name = "rdn1";
            this.rdn1.Size = new System.Drawing.Size(56, 17);
            this.rdn1.TabIndex = 161;
            this.rdn1.TabStop = true;
            this.rdn1.Text = "Check";
            this.rdn1.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Location = new System.Drawing.Point(210, 310);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(27, 23);
            this.btn6.TabIndex = 171;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            // 
            // lblT
            // 
            this.lblT.AutoSize = true;
            this.lblT.BackColor = System.Drawing.Color.White;
            this.lblT.Location = new System.Drawing.Point(67, 149);
            this.lblT.Name = "lblT";
            this.lblT.Size = new System.Drawing.Size(370, 26);
            this.lblT.TabIndex = 160;
            this.lblT.Text = "Which SQL constraint is used to ensure that the values in a column matches \r\nthe " +
    "values in a primary key of another table?";
            // 
            // btn5
            // 
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Location = new System.Drawing.Point(187, 310);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(27, 23);
            this.btn5.TabIndex = 170;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // lblQuestions
            // 
            this.lblQuestions.AutoSize = true;
            this.lblQuestions.BackColor = System.Drawing.Color.White;
            this.lblQuestions.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestions.Location = new System.Drawing.Point(44, 121);
            this.lblQuestions.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQuestions.Name = "lblQuestions";
            this.lblQuestions.Size = new System.Drawing.Size(118, 13);
            this.lblQuestions.TabIndex = 159;
            this.lblQuestions.Text = "Questions 3 out of 10";
            // 
            // btn1
            // 
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Location = new System.Drawing.Point(90, 310);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(27, 23);
            this.btn1.TabIndex = 169;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            // 
            // lblProgramming
            // 
            this.lblProgramming.AutoSize = true;
            this.lblProgramming.BackColor = System.Drawing.Color.White;
            this.lblProgramming.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgramming.Location = new System.Drawing.Point(23, 83);
            this.lblProgramming.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgramming.Name = "lblProgramming";
            this.lblProgramming.Size = new System.Drawing.Size(140, 17);
            this.lblProgramming.TabIndex = 157;
            this.lblProgramming.Text = " Programming Quiz 1";
            // 
            // btn2
            // 
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Location = new System.Drawing.Point(114, 310);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(27, 23);
            this.btn2.TabIndex = 168;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.White;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(44, 55);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(109, 13);
            this.lblWelcome.TabIndex = 158;
            this.lblWelcome.Text = "Welcome, John Doe";
            // 
            // btn4
            // 
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Location = new System.Drawing.Point(162, 310);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(27, 23);
            this.btn4.TabIndex = 167;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Location = new System.Drawing.Point(139, 310);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(27, 23);
            this.btn3.TabIndex = 166;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Location = new System.Drawing.Point(186, 551);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(472, 149);
            this.panel3.TabIndex = 157;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 21);
            this.label1.TabIndex = 158;
            this.label1.Text = " 📝 Test Setup";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(3, 3);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(466, 143);
            this.textBox2.TabIndex = 0;
            this.textBox2.Text = "\r\n\r\n\r\n ● Assign to specific sections\r\n ● Randomize questions\r\n ● Randomize choice" +
    "s\r\n ● Show/hide correct answers after submission\r\n ● Allow review";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Location = new System.Drawing.Point(722, 551);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(470, 148);
            this.panel4.TabIndex = 158;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 21);
            this.label2.TabIndex = 120;
            this.label2.Text = "📝 Test Taking";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(3, 3);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(464, 142);
            this.textBox3.TabIndex = 0;
            this.textBox3.Text = " \r\n\r\n\r\n ● Student authentication\r\n ● Timer display\r\n ● Progress indicator\r\n ● Aut" +
    "o-submit when time expires";
            // 
            // lblLogout
            // 
            this.lblLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLogout.AutoSize = true;
            this.lblLogout.BackColor = System.Drawing.Color.SteelBlue;
            this.lblLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogout.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogout.ForeColor = System.Drawing.Color.White;
            this.lblLogout.Location = new System.Drawing.Point(1125, 48);
            this.lblLogout.Name = "lblLogout";
            this.lblLogout.Size = new System.Drawing.Size(70, 19);
            this.lblLogout.TabIndex = 159;
            this.lblLogout.Text = "LOGOUT ";
            this.lblLogout.Click += new System.EventHandler(this.lblLogout_Click);
            // 
            // pbNotif
            // 
            this.pbNotif.BackColor = System.Drawing.Color.SteelBlue;
            this.pbNotif.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbNotif.Image = ((System.Drawing.Image)(resources.GetObject("pbNotif.Image")));
            this.pbNotif.Location = new System.Drawing.Point(1084, 39);
            this.pbNotif.Name = "pbNotif";
            this.pbNotif.Size = new System.Drawing.Size(25, 28);
            this.pbNotif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbNotif.TabIndex = 191;
            this.pbNotif.TabStop = false;
            this.pbNotif.Click += new System.EventHandler(this.pbNotif_Click);
            // 
            // Testadministration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1234, 712);
            this.Controls.Add(this.pbNotif);
            this.Controls.Add(this.lblLogout);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.textBox15);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Testadministration";
            this.Load += new System.EventHandler(this.Testadministration_Load);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNotif)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTestSetup;
        private System.Windows.Forms.Label lblTestTaking;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblConfig;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.Button btnAssign;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.CheckBox cbPeriod3;
        private System.Windows.Forms.CheckBox cbPeriod2;
        private System.Windows.Forms.CheckBox cbPeriod1;
        private System.Windows.Forms.CheckBox cbAllow;
        private System.Windows.Forms.CheckBox cbShow;
        private System.Windows.Forms.CheckBox cbRandomizeA;
        private System.Windows.Forms.CheckBox cbRandomizeQ;
        private System.Windows.Forms.Label lblTestSettings;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblQuestions;
        private System.Windows.Forms.Label lblProgramming;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.RadioButton rdn1;
        private System.Windows.Forms.Label lblT;
        private System.Windows.Forms.RadioButton rdn4;
        private System.Windows.Forms.RadioButton rdn3;
        private System.Windows.Forms.RadioButton rdn2;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.TextBox txtbAuto;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblLogout;
        private System.Windows.Forms.PictureBox pbNotif;
    }
}