﻿namespace Student_Assessment_System_with_Item_Analysis.Source.Forms
{
    partial class lblSubjectcourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(lblSubjectcourse));
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lblProgramming = new System.Windows.Forms.Label();
            this.btnEditSub = new System.Windows.Forms.Button();
            this.lblSCInfo = new System.Windows.Forms.Label();
            this.lblCourseSections = new System.Windows.Forms.Label();
            this.lblSectionCodes = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnEditD = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.cmbTerm = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbFilter = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.pbJohn = new System.Windows.Forms.PictureBox();
            this.lblPeriod = new System.Windows.Forms.Label();
            this.lblGrade = new System.Windows.Forms.Label();
            this.btnStatus = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.pnlStudentList = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblG = new System.Windows.Forms.Label();
            this.lblP = new System.Windows.Forms.Label();
            this.lblStudent = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnSear = new System.Windows.Forms.Button();
            this.cmbAny = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblStu = new System.Windows.Forms.Label();
            this.lblStudentInfo = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblPerio = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSu = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTeacher = new System.Windows.Forms.Label();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnEd = new System.Windows.Forms.Button();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button11 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblTeacherAss = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.lblFall = new System.Windows.Forms.Label();
            this.lblAcademic = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.lblSpring = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.lblLogout = new System.Windows.Forms.Label();
            this.pbNotif = new System.Windows.Forms.PictureBox();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJohn)).BeginInit();
            this.pnlStudentList.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNotif)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.button3);
            this.panel6.Controls.Add(this.button5);
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.button7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(160, 735);
            this.panel6.TabIndex = 61;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(44, 25);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(68, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 48;
            this.pictureBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-3, 381);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(163, 48);
            this.button1.TabIndex = 46;
            this.button1.Text = "📊 Reports";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 318);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(163, 46);
            this.button2.TabIndex = 45;
            this.button2.Text = "💻 Test Administration";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(-3, 435);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(163, 48);
            this.button3.TabIndex = 47;
            this.button3.Text = "⚙️ Settings";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(-3, 250);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(160, 49);
            this.button5.TabIndex = 43;
            this.button5.Text = "❔ Question Bank";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 184);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(160, 60);
            this.button6.TabIndex = 42;
            this.button6.Text = "📚 Subjects and Courses";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 125);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(160, 53);
            this.button7.TabIndex = 41;
            this.button7.Text = "🏠︎ Dashboard";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.SteelBlue;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(180, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(286, 37);
            this.label9.TabIndex = 79;
            this.label9.Text = "Subjects and Courses";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // lblProgramming
            // 
            this.lblProgramming.AutoSize = true;
            this.lblProgramming.BackColor = System.Drawing.Color.White;
            this.lblProgramming.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgramming.Location = new System.Drawing.Point(243, 184);
            this.lblProgramming.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgramming.Name = "lblProgramming";
            this.lblProgramming.Size = new System.Drawing.Size(92, 17);
            this.lblProgramming.TabIndex = 90;
            this.lblProgramming.Text = "Programming";
            // 
            // btnEditSub
            // 
            this.btnEditSub.BackColor = System.Drawing.Color.SteelBlue;
            this.btnEditSub.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEditSub.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditSub.ForeColor = System.Drawing.Color.White;
            this.btnEditSub.Location = new System.Drawing.Point(491, 351);
            this.btnEditSub.Margin = new System.Windows.Forms.Padding(2);
            this.btnEditSub.Name = "btnEditSub";
            this.btnEditSub.Size = new System.Drawing.Size(119, 28);
            this.btnEditSub.TabIndex = 99;
            this.btnEditSub.Text = "✏️ Edit Subject";
            this.btnEditSub.UseVisualStyleBackColor = false;
            // 
            // lblSCInfo
            // 
            this.lblSCInfo.AutoSize = true;
            this.lblSCInfo.BackColor = System.Drawing.Color.White;
            this.lblSCInfo.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSCInfo.Location = new System.Drawing.Point(241, 138);
            this.lblSCInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSCInfo.Name = "lblSCInfo";
            this.lblSCInfo.Size = new System.Drawing.Size(300, 30);
            this.lblSCInfo.TabIndex = 102;
            this.lblSCInfo.Text = "Subject/Course Information";
            // 
            // lblCourseSections
            // 
            this.lblCourseSections.AutoSize = true;
            this.lblCourseSections.BackColor = System.Drawing.Color.White;
            this.lblCourseSections.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourseSections.Location = new System.Drawing.Point(692, 138);
            this.lblCourseSections.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCourseSections.Name = "lblCourseSections";
            this.lblCourseSections.Size = new System.Drawing.Size(176, 30);
            this.lblCourseSections.TabIndex = 104;
            this.lblCourseSections.Text = "Course Sections";
            // 
            // lblSectionCodes
            // 
            this.lblSectionCodes.AutoSize = true;
            this.lblSectionCodes.BackColor = System.Drawing.Color.White;
            this.lblSectionCodes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSectionCodes.Location = new System.Drawing.Point(694, 188);
            this.lblSectionCodes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSectionCodes.Name = "lblSectionCodes";
            this.lblSectionCodes.Size = new System.Drawing.Size(103, 17);
            this.lblSectionCodes.TabIndex = 105;
            this.lblSectionCodes.Text = "Section Codes:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.White;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(747, 272);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(56, 15);
            this.lblName.TabIndex = 106;
            this.lblName.Text = "John Doe";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(680, 381);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 17);
            this.label21.TabIndex = 107;
            // 
            // btnEditD
            // 
            this.btnEditD.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnEditD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditD.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditD.Location = new System.Drawing.Point(499, 596);
            this.btnEditD.Margin = new System.Windows.Forms.Padding(2);
            this.btnEditD.Name = "btnEditD";
            this.btnEditD.Size = new System.Drawing.Size(70, 28);
            this.btnEditD.TabIndex = 115;
            this.btnEditD.Text = "Edit";
            this.btnEditD.UseVisualStyleBackColor = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.SteelBlue;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(152, 0);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(1426, 94);
            this.textBox3.TabIndex = 127;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddStudent.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStudent.ForeColor = System.Drawing.Color.White;
            this.btnAddStudent.Location = new System.Drawing.Point(962, 352);
            this.btnAddStudent.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(97, 27);
            this.btnAddStudent.TabIndex = 129;
            this.btnAddStudent.Text = "+ Add Student";
            this.btnAddStudent.UseVisualStyleBackColor = false;
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(257, 223);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(326, 21);
            this.cmbYear.TabIndex = 130;
            this.cmbYear.Text = "Select Year:";
            this.cmbYear.SelectedIndexChanged += new System.EventHandler(this.cmbYear_SelectedIndexChanged);
            // 
            // cmbTerm
            // 
            this.cmbTerm.FormattingEnabled = true;
            this.cmbTerm.Location = new System.Drawing.Point(257, 263);
            this.cmbTerm.Name = "cmbTerm";
            this.cmbTerm.Size = new System.Drawing.Size(326, 21);
            this.cmbTerm.TabIndex = 131;
            this.cmbTerm.Text = "Select Term:";
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(234, 118);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(388, 280);
            this.textBox4.TabIndex = 87;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(254, 296);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(344, 26);
            this.label1.TabIndex = 132;
            this.label1.Text = "Introduction to programming involves learning to give computers\r\nstep-by-step ins" +
    "tructions (code) to solve problems";
            // 
            // cmbFilter
            // 
            this.cmbFilter.FormattingEnabled = true;
            this.cmbFilter.Location = new System.Drawing.Point(820, 184);
            this.cmbFilter.Name = "cmbFilter";
            this.cmbFilter.Size = new System.Drawing.Size(142, 21);
            this.cmbFilter.TabIndex = 133;
            this.cmbFilter.Text = "Filter any";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.White;
            this.btnSearch.Location = new System.Drawing.Point(984, 184);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 134;
            this.btnSearch.Text = "⌕ Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // pbJohn
            // 
            this.pbJohn.BackColor = System.Drawing.Color.White;
            this.pbJohn.ErrorImage = null;
            this.pbJohn.Image = ((System.Drawing.Image)(resources.GetObject("pbJohn.Image")));
            this.pbJohn.InitialImage = null;
            this.pbJohn.Location = new System.Drawing.Point(703, 263);
            this.pbJohn.Name = "pbJohn";
            this.pbJohn.Size = new System.Drawing.Size(39, 30);
            this.pbJohn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbJohn.TabIndex = 135;
            this.pbJohn.TabStop = false;
            // 
            // lblPeriod
            // 
            this.lblPeriod.AutoSize = true;
            this.lblPeriod.BackColor = System.Drawing.Color.White;
            this.lblPeriod.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeriod.Location = new System.Drawing.Point(817, 273);
            this.lblPeriod.Name = "lblPeriod";
            this.lblPeriod.Size = new System.Drawing.Size(61, 13);
            this.lblPeriod.TabIndex = 136;
            this.lblPeriod.Text = "ALG101-01";
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.BackColor = System.Drawing.Color.White;
            this.lblGrade.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrade.Location = new System.Drawing.Point(908, 273);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(28, 13);
            this.lblGrade.TabIndex = 137;
            this.lblGrade.Text = "89%";
            // 
            // btnStatus
            // 
            this.btnStatus.BackColor = System.Drawing.Color.LightGreen;
            this.btnStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStatus.Location = new System.Drawing.Point(972, 268);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(46, 22);
            this.btnStatus.TabIndex = 138;
            this.btnStatus.Text = "Good";
            this.btnStatus.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.White;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEdit.Location = new System.Drawing.Point(1024, 269);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(25, 21);
            this.btnEdit.TabIndex = 139;
            this.btnEdit.Text = "...";
            this.btnEdit.UseVisualStyleBackColor = false;
            // 
            // pnlStudentList
            // 
            this.pnlStudentList.Controls.Add(this.lblStatus);
            this.pnlStudentList.Controls.Add(this.lblG);
            this.pnlStudentList.Controls.Add(this.lblP);
            this.pnlStudentList.Controls.Add(this.lblStudent);
            this.pnlStudentList.Location = new System.Drawing.Point(703, 223);
            this.pnlStudentList.Name = "pnlStudentList";
            this.pnlStudentList.Size = new System.Drawing.Size(356, 34);
            this.pnlStudentList.TabIndex = 140;
            this.pnlStudentList.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(289, 13);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(37, 13);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Status";
            // 
            // lblG
            // 
            this.lblG.AutoSize = true;
            this.lblG.Location = new System.Drawing.Point(211, 13);
            this.lblG.Name = "lblG";
            this.lblG.Size = new System.Drawing.Size(36, 13);
            this.lblG.TabIndex = 2;
            this.lblG.Text = "Grade";
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.Location = new System.Drawing.Point(128, 13);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(37, 13);
            this.lblP.TabIndex = 1;
            this.lblP.Text = "Period";
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Location = new System.Drawing.Point(3, 13);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(44, 13);
            this.lblStudent.TabIndex = 0;
            this.lblStudent.Text = "Student";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(684, 118);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(388, 280);
            this.textBox6.TabIndex = 100;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(253, 529);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(356, 34);
            this.panel1.TabIndex = 154;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(128, 13);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(18, 13);
            this.lblID.TabIndex = 157;
            this.lblID.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(308, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Grade";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(184, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Period";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Student";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(584, 575);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(25, 21);
            this.button4.TabIndex = 153;
            this.button4.Text = "...";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.LightGreen;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(537, 575);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(46, 22);
            this.button8.TabIndex = 152;
            this.button8.Text = "Good";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(488, 579);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 151;
            this.label6.Text = "89%";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(368, 578);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 150;
            this.label7.Text = "ALG101-01";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(253, 569);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 149;
            this.pictureBox1.TabStop = false;
            // 
            // BtnSear
            // 
            this.BtnSear.BackColor = System.Drawing.Color.White;
            this.BtnSear.Location = new System.Drawing.Point(328, 488);
            this.BtnSear.Name = "BtnSear";
            this.BtnSear.Size = new System.Drawing.Size(75, 23);
            this.BtnSear.TabIndex = 148;
            this.BtnSear.Text = "⌕ Search";
            this.BtnSear.UseVisualStyleBackColor = false;
            this.BtnSear.Click += new System.EventHandler(this.BtnSear_Click);
            // 
            // cmbAny
            // 
            this.cmbAny.FormattingEnabled = true;
            this.cmbAny.Location = new System.Drawing.Point(498, 488);
            this.cmbAny.Name = "cmbAny";
            this.cmbAny.Size = new System.Drawing.Size(111, 21);
            this.cmbAny.TabIndex = 147;
            this.cmbAny.Text = "Any";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(230, 687);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 145;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(297, 578);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 15);
            this.label10.TabIndex = 144;
            this.label10.Text = "John Doe";
            // 
            // lblStu
            // 
            this.lblStu.AutoSize = true;
            this.lblStu.BackColor = System.Drawing.Color.White;
            this.lblStu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStu.Location = new System.Drawing.Point(250, 490);
            this.lblStu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStu.Name = "lblStu";
            this.lblStu.Size = new System.Drawing.Size(68, 17);
            this.lblStu.TabIndex = 143;
            this.lblStu.Text = "Students:";
            // 
            // lblStudentInfo
            // 
            this.lblStudentInfo.AutoSize = true;
            this.lblStudentInfo.BackColor = System.Drawing.Color.White;
            this.lblStudentInfo.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentInfo.Location = new System.Drawing.Point(242, 444);
            this.lblStudentInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentInfo.Name = "lblStudentInfo";
            this.lblStudentInfo.Size = new System.Drawing.Size(223, 30);
            this.lblStudentInfo.TabIndex = 142;
            this.lblStudentInfo.Text = "Student Information";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(234, 424);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(388, 280);
            this.textBox1.TabIndex = 141;
            // 
            // lblPerio
            // 
            this.lblPerio.AutoSize = true;
            this.lblPerio.BackColor = System.Drawing.Color.White;
            this.lblPerio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerio.Location = new System.Drawing.Point(437, 490);
            this.lblPerio.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPerio.Name = "lblPerio";
            this.lblPerio.Size = new System.Drawing.Size(53, 17);
            this.lblPerio.TabIndex = 155;
            this.lblPerio.Text = "Period:";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl1.Location = new System.Drawing.Point(446, 578);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(13, 13);
            this.lbl1.TabIndex = 156;
            this.lbl1.Text = "1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblSu);
            this.panel2.Controls.Add(this.lblEmail);
            this.panel2.Controls.Add(this.lblTeacher);
            this.panel2.Location = new System.Drawing.Point(703, 529);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 34);
            this.panel2.TabIndex = 170;
            // 
            // lblSu
            // 
            this.lblSu.AutoSize = true;
            this.lblSu.Location = new System.Drawing.Point(211, 13);
            this.lblSu.Name = "lblSu";
            this.lblSu.Size = new System.Drawing.Size(43, 13);
            this.lblSu.TabIndex = 2;
            this.lblSu.Text = "Subject";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(128, 13);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 1;
            this.lblEmail.Text = "Email";
            // 
            // lblTeacher
            // 
            this.lblTeacher.AutoSize = true;
            this.lblTeacher.Location = new System.Drawing.Point(3, 13);
            this.lblTeacher.Name = "lblTeacher";
            this.lblTeacher.Size = new System.Drawing.Size(47, 13);
            this.lblTeacher.TabIndex = 0;
            this.lblTeacher.Text = "Teacher";
            // 
            // btnDel
            // 
            this.btnDel.BackColor = System.Drawing.Color.White;
            this.btnDel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDel.Location = new System.Drawing.Point(1021, 574);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(48, 21);
            this.btnDel.TabIndex = 169;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = false;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnEd
            // 
            this.btnEd.BackColor = System.Drawing.Color.White;
            this.btnEd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEd.Location = new System.Drawing.Point(969, 574);
            this.btnEd.Name = "btnEd";
            this.btnEd.Size = new System.Drawing.Size(46, 21);
            this.btnEd.TabIndex = 168;
            this.btnEd.Text = "Edit";
            this.btnEd.UseVisualStyleBackColor = false;
            // 
            // lblDatabase
            // 
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.BackColor = System.Drawing.Color.White;
            this.lblDatabase.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabase.Location = new System.Drawing.Point(908, 578);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Size = new System.Drawing.Size(55, 13);
            this.lblDatabase.TabIndex = 167;
            this.lblDatabase.Text = "Database";
            this.lblDatabase.Click += new System.EventHandler(this.label15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(817, 579);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 13);
            this.label16.TabIndex = 166;
            this.label16.Text = "teacher.1@u..";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(703, 569);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 165;
            this.pictureBox2.TabStop = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(984, 490);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 164;
            this.button11.Text = "⌕ Search";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(820, 490);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(142, 21);
            this.comboBox1.TabIndex = 163;
            this.comboBox1.Text = "Filter any";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(680, 687);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 17);
            this.label17.TabIndex = 161;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(747, 578);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 15);
            this.label18.TabIndex = 160;
            this.label18.Text = "Teacher1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(694, 494);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 17);
            this.label19.TabIndex = 159;
            this.label19.Text = "Section Codes:";
            // 
            // lblTeacherAss
            // 
            this.lblTeacherAss.AutoSize = true;
            this.lblTeacherAss.BackColor = System.Drawing.Color.White;
            this.lblTeacherAss.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeacherAss.Location = new System.Drawing.Point(692, 444);
            this.lblTeacherAss.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeacherAss.Name = "lblTeacherAss";
            this.lblTeacherAss.Size = new System.Drawing.Size(231, 30);
            this.lblTeacherAss.TabIndex = 158;
            this.lblTeacherAss.Text = "Teacher Assignments";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(684, 424);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(388, 280);
            this.textBox2.TabIndex = 157;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(1376, 273);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(120, 27);
            this.btnAdd.TabIndex = 176;
            this.btnAdd.Text = "+ Add New Term";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(1120, 381);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(0, 17);
            this.label20.TabIndex = 175;
            // 
            // lblFall
            // 
            this.lblFall.AutoSize = true;
            this.lblFall.BackColor = System.Drawing.Color.White;
            this.lblFall.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFall.Location = new System.Drawing.Point(1134, 192);
            this.lblFall.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFall.Name = "lblFall";
            this.lblFall.Size = new System.Drawing.Size(111, 15);
            this.lblFall.TabIndex = 174;
            this.lblFall.Text = "2023 - Fall Semester";
            this.lblFall.Click += new System.EventHandler(this.lblFall_Click);
            // 
            // lblAcademic
            // 
            this.lblAcademic.AutoSize = true;
            this.lblAcademic.BackColor = System.Drawing.Color.White;
            this.lblAcademic.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAcademic.Location = new System.Drawing.Point(1132, 132);
            this.lblAcademic.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAcademic.Name = "lblAcademic";
            this.lblAcademic.Size = new System.Drawing.Size(316, 30);
            this.lblAcademic.TabIndex = 172;
            this.lblAcademic.Text = "Academic Term Management";
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Location = new System.Drawing.Point(1124, 118);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(388, 204);
            this.textBox5.TabIndex = 171;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Location = new System.Drawing.Point(1435, 187);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(48, 21);
            this.button9.TabIndex = 183;
            this.button9.Text = "Delete";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(1366, 189);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(46, 21);
            this.button10.TabIndex = 182;
            this.button10.Text = "Edit";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // lblSpring
            // 
            this.lblSpring.AutoSize = true;
            this.lblSpring.BackColor = System.Drawing.Color.White;
            this.lblSpring.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpring.Location = new System.Drawing.Point(1134, 225);
            this.lblSpring.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSpring.Name = "lblSpring";
            this.lblSpring.Size = new System.Drawing.Size(127, 15);
            this.lblSpring.TabIndex = 184;
            this.lblSpring.Text = "2024 - Spring Semester";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(1366, 223);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(46, 21);
            this.button13.TabIndex = 185;
            this.button13.Text = "Edit";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Location = new System.Drawing.Point(1435, 222);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(48, 21);
            this.button14.TabIndex = 186;
            this.button14.Text = "Delete";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // lblLogout
            // 
            this.lblLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLogout.AutoSize = true;
            this.lblLogout.BackColor = System.Drawing.Color.SteelBlue;
            this.lblLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogout.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogout.ForeColor = System.Drawing.Color.White;
            this.lblLogout.Location = new System.Drawing.Point(1467, 48);
            this.lblLogout.Name = "lblLogout";
            this.lblLogout.Size = new System.Drawing.Size(70, 19);
            this.lblLogout.TabIndex = 187;
            this.lblLogout.Text = "LOGOUT ";
            this.lblLogout.Click += new System.EventHandler(this.lblLogout_Click);
            // 
            // pbNotif
            // 
            this.pbNotif.BackColor = System.Drawing.Color.SteelBlue;
            this.pbNotif.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbNotif.Image = ((System.Drawing.Image)(resources.GetObject("pbNotif.Image")));
            this.pbNotif.Location = new System.Drawing.Point(1423, 41);
            this.pbNotif.Name = "pbNotif";
            this.pbNotif.Size = new System.Drawing.Size(25, 28);
            this.pbNotif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbNotif.TabIndex = 190;
            this.pbNotif.TabStop = false;
            // 
            // lblSubjectcourse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1573, 735);
            this.Controls.Add(this.pbNotif);
            this.Controls.Add(this.lblLogout);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.lblSpring);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lblFall);
            this.Controls.Add(this.lblAcademic);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnEd);
            this.Controls.Add(this.lblDatabase);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lblTeacherAss);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblPerio);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BtnSear);
            this.Controls.Add(this.cmbAny);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblStu);
            this.Controls.Add(this.lblStudentInfo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pnlStudentList);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnStatus);
            this.Controls.Add(this.lblGrade);
            this.Controls.Add(this.lblPeriod);
            this.Controls.Add(this.pbJohn);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.cmbFilter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbTerm);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.btnAddStudent);
            this.Controls.Add(this.btnEditD);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblSectionCodes);
            this.Controls.Add(this.lblCourseSections);
            this.Controls.Add(this.lblSCInfo);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.btnEditSub);
            this.Controls.Add(this.lblProgramming);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.textBox3);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "lblSubjectcourse";
            this.Text = " ";
            this.Load += new System.EventHandler(this.lblsubjectcourse_Load);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJohn)).EndInit();
            this.pnlStudentList.ResumeLayout(false);
            this.pnlStudentList.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNotif)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblProgramming;
        private System.Windows.Forms.Button btnEditSub;
        private System.Windows.Forms.Label lblSCInfo;
        private System.Windows.Forms.Label lblCourseSections;
        private System.Windows.Forms.Label lblSectionCodes;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnEditD;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.ComboBox cmbTerm;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.PictureBox pbJohn;
        private System.Windows.Forms.Label lblPeriod;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Panel pnlStudentList;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblG;
        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BtnSear;
        private System.Windows.Forms.ComboBox cmbAny;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblStu;
        private System.Windows.Forms.Label lblStudentInfo;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblPerio;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblSu;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblTeacher;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnEd;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblTeacherAss;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblFall;
        private System.Windows.Forms.Label lblAcademic;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label lblSpring;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label lblLogout;
        private System.Windows.Forms.PictureBox pbNotif;
    }
}